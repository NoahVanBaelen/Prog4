#include "BaseComponent.h"

void BaseComponent::Update(float)
{}

void BaseComponent::FixedUpdate(float)
{
}

void BaseComponent::Render() const
{

}
