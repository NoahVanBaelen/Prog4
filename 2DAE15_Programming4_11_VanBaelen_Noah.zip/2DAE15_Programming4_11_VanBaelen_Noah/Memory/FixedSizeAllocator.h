#pragma once
#include "MemoryAllocator.h"

namespace dae
{
	class FixedSizeAllocator final : public MemoryAllocator
	{
		struct Header
		{
			size_t count;
		};
		struct Block : Header
		{
			Block* next;
			char* data;

			explicit Block(int dataSize) : next(nullptr), data(new char[dataSize])
			{}

			/*~Block()
			{
				delete[] data;
			}*/
		};

		size_t nbBlocks;
		Block** pool;
		Block* head;

		static void FillAllocatedBlock(Block* block, size_t nbBytes);

	public:
		explicit FixedSizeAllocator(size_t,int blockSize);
		virtual ~FixedSizeAllocator();

		void* Acquire(size_t nbBytes) override;
		void Release(void*) override;

		// remove default copy & move constructors/assignment operators
		FixedSizeAllocator(const FixedSizeAllocator&) = delete;
		FixedSizeAllocator(FixedSizeAllocator&&) = delete;
		FixedSizeAllocator& operator= (const FixedSizeAllocator&) = delete;
		FixedSizeAllocator& operator= (const FixedSizeAllocator&&) = delete;
	};
}


