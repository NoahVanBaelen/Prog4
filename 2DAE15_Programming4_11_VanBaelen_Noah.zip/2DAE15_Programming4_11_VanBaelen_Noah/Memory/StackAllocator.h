#pragma once
#include "MemoryAllocator.h"

namespace dae
{
	class StackAllocator final : public MemoryAllocator
	{
		struct Header
		{
			size_t count;
		};
		struct Block : Header
		{
			const static int size = 16; // this is a different value for x64/Win32 targets;
			union
			{
				Block* next;
				char data[size - sizeof(Header)];
			};
		};

		size_t nbBlocks;
		size_t marker;
		Block* pool;
		Block* head;

		static void FillAllocatedBlock(Block* block, size_t nbBytes);

	public:
		explicit StackAllocator(size_t);
		virtual ~StackAllocator();

		void* Acquire(size_t nbBytes) override;
		void Release(void*) override;
		void Release(size_t);
		size_t GetMarker();

		// remove default copy & move constructors/assignment operators
		StackAllocator(const StackAllocator&) = delete;
		StackAllocator(StackAllocator&&) = delete;
		StackAllocator& operator= (const StackAllocator&) = delete;
		StackAllocator& operator= (const StackAllocator&&) = delete;
	};
}

