#include "CppUnitTest.h"
#include "..\Memory\MemoryOverrides.h"
#include "..\Memory\StackAllocator.h"

#include <vector>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace dae
{
	const size_t allocator_size = 1024;
	const size_t pointer_size = sizeof(void*); // this is a different value for x64/Win32 targets

	class Object
	{
	public:
		int m_integer{ 0 };
		float m_float{ 0 };
	};

	TEST_CLASS(StackAllocatorTest)
	{
	public:
        TEST_METHOD(StackSingleAllocationObjectNewTest)
        {
            StackAllocator allocator(allocator_size);

            const size_t test_size = allocator_size - sizeof(Object*);
            Object* pointer;
            pointer = new (allocator.Acquire(test_size)) Object();
            Assert::IsNotNull(pointer);
            std::memset(pointer, 1, test_size);
            Assert::IsFalse(pointer->m_float == 0);
            Assert::IsFalse(pointer->m_integer == 0);
            allocator.Release(pointer);
        }

        TEST_METHOD(StackSingleAllocationObjectReinterpretCastTest)
        {
            StackAllocator allocator(allocator_size);

            const size_t test_size = allocator_size - sizeof(Object*);
            Object* pointer;
            pointer = reinterpret_cast<Object*>(allocator.Acquire(sizeof(Object*)));
            Assert::IsNotNull(pointer);
            std::memset(pointer, 1, test_size);
            Assert::IsFalse(pointer->m_float == 0);
            Assert::IsFalse(pointer->m_integer == 0);
            allocator.Release(pointer);
        }

        TEST_METHOD(StackFragmentation)
        {
            std::vector<float*>vectorFloats{};
            const size_t allocatorSize{ 1000 }; // 1K bytes
            StackAllocator allocator(allocatorSize);
            size_t currentFreeMemory{ allocatorSize };
            while (currentFreeMemory > sizeof(float*))
            {
                const size_t test_size = currentFreeMemory - sizeof(float*);
                currentFreeMemory -= sizeof(float*);
                float* pointer;
                pointer = reinterpret_cast<float*>(allocator.Acquire(sizeof(float*)));
                Assert::IsNotNull(pointer);
                std::memset(pointer, 1, test_size);
                vectorFloats.push_back(pointer);
            }

            allocator.Release(vectorFloats[10]);
            allocator.Release(vectorFloats[15]);
            allocator.Release(vectorFloats[20]);

            const size_t test_size = currentFreeMemory + (sizeof(float*) * 3) - sizeof(Object*);
            Object* pointer;
            pointer = reinterpret_cast<Object*>(allocator.Acquire(sizeof(Object*)));
            Assert::IsNotNull(pointer);
            std::memset(pointer, 1, test_size);

        }

        TEST_METHOD(StackSingleAllocation)
        {
            StackAllocator allocator(allocator_size);

            const size_t test_size = allocator_size - pointer_size;
            void* pointer;
            pointer = allocator.Acquire(test_size);
            Assert::IsNotNull(pointer);
            std::memset(pointer, 1, test_size);
            allocator.Release(pointer);
        }

        TEST_METHOD(StackInvalidRelease)
        {
            StackAllocator allocator(allocator_size);

            void* pointer = new char;
            Assert::ExpectException<std::runtime_error>([&]() { allocator.Release(pointer); });
            delete pointer;
        }

        TEST_METHOD(StackTwoAllocations)
        {
            StackAllocator allocator(allocator_size);

            const size_t test_size = allocator_size / 2 - pointer_size;
            void* pointer_a{};
            void* pointer_b{};
            pointer_a = allocator.Acquire(test_size);
            pointer_b = allocator.Acquire(test_size);
            Assert::IsNotNull(pointer_a);
            Assert::IsNotNull(pointer_b);
            std::memset(pointer_a, 1, test_size);
            std::memset(pointer_b, 1, test_size);
            allocator.Release(pointer_a);
            allocator.Release(pointer_b);
        }

        TEST_METHOD(StackManySmallAllocations)
        {
            StackAllocator allocator(allocator_size);

            const size_t nbPieces = allocator_size / 16;
            void** pointers = new void* [nbPieces];
            const size_t test_size = allocator_size / nbPieces - pointer_size;
            for (int i = 0; i < nbPieces; i++)
            {
                pointers[i] = allocator.Acquire(test_size);
                Assert::IsNotNull(pointers[i]);
                std::memset(pointers[i], 1, test_size);
            }
            for (int i = 0; i < nbPieces; i++)
                allocator.Release(pointers[i]);
            delete[] pointers;
        }

        TEST_METHOD(StackOutOfMemory)
        {
            StackAllocator allocator(allocator_size);
            const size_t test_size = allocator_size - pointer_size;
            void* pointer;
            pointer = allocator.Acquire(test_size);
            Assert::IsNotNull(pointer);
            std::memset(pointer, 1, test_size);
            Assert::ExpectException<std::runtime_error>([&]() { allocator.Acquire(16); });
            allocator.Release(pointer);
        }
	};
}